package com.example.clander.view;

/**
 * 选中日期的监听事件
 */
public interface ClickDataListener {
	void clickData(String year, String month, String day);
}
