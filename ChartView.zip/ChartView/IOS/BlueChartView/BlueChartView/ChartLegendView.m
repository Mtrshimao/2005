//
//  ChartLegendView.m
//  BlueChartView
//
//  Created by blue on 16/8/31.
//  Copyright © 2016年 chengli. All rights reserved.
//

#import "ChartLegendView.h"

@implementation ChartLegendView



@end
